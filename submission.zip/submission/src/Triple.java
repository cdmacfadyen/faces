/**
 * Triple for holding the mesh.csv info.
 */
public class Triple {   
    protected int first;
    protected int second;
    protected int third;

    public Triple(int first, int second, int third) {
        this.first = first;
        this.second = second;
        this.third = third;
    }
}

