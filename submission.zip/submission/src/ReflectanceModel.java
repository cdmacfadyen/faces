public enum ReflectanceModel {
    MESH_ONLY, NONE, LAMBERT
}
