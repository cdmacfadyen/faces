public enum ShadingModel {
    NONE, FLAT_SHADING
}
